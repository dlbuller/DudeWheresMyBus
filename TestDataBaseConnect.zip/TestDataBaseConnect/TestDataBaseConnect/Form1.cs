﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Odbc;
using MySqlConnector;
using System.Data;


namespace TestDataBaseConnect
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection conn = null;
        private void connectButton_Click(object sender, EventArgs e)
        {
            string myConnectionString;

            //myConnectionString = "Server=bullerman.crwam3sjtzbj.us-east-2.rds.amazonaws.com;Port=3306;Uid=admin;Pwd=Ollie*651;";
            myConnectionString = "Server=bullerman2.crwam3sjtzbj.us-east-2.rds.amazonaws.com;Port=3306;Database=bullerman2;Uid=admin;Pwd=Ollie*651;";
            try
            {
                conn = new MySqlConnection();
                conn.ConnectionString = myConnectionString;
                conn.Open();
            }

            catch (MySqlException ex)
            {
                System.Diagnostics.Debug.WriteLine(ex);
            }


            //string connectString = "DRIVER={ODBC Driver 17 for SQL Server};" + "SERVER=EESTAGESQL\\ET;" + "DATABASE=SysTestDB;" + "Trusted_Connection=yes;";
            //OdbcConnection connection = new OdbcConnection(connectString);

            //connection.Open();
            //OdbcCommand command = connection.CreateCommand();
            //command.CommandText = "SELECT LAST (10) * FROM dbo.CharacterizationTest";

            //command.CommandText = "INSERT INTO dbo.CharacterizationTest (TestRun, Project, Slot, HandleNumber, TestName, TestStep, TestStart, TestEnd, Temperature, ActivationType, TouchoffDistance, ActivationDistance, ResultDistance) Values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            //command.Parameters.AddWithValue("TestRun", 1);
            //command.Parameters.AddWithValue("Project", "B233");
            //command.Parameters.AddWithValue("Slot", "slot1");
            //command.Parameters.AddWithValue("HandleNumber", "1");
            //command.Parameters.AddWithValue("TestStep", "Test 1 Test");
            //command.Parameters.AddWithValue("TestStart", DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
            //command.Parameters.AddWithValue("TestEnd", DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
            //command.Parameters.AddWithValue("Temperature", 25.12);
            //command.Parameters.AddWithValue("ActivationType", "Lock");
            //command.Parameters.AddWithValue("TouchoffDistance", 120);
            //command.Parameters.AddWithValue("ActivationDistance", 123);
            //command.Parameters.AddWithValue("ResultDistance", 3);
            //command.ExecuteNonQuery();
            //OdbcDataReader reader = command.ExecuteReader();
            //while(reader.Read())
            //{
            //    System.Diagnostics.Debug.WriteLine(reader[0].ToString());
            //    //System.Diagnostics.Debug.WriteLine(reader[1].ToString());
            //    //System.Diagnostics.Debug.WriteLine(reader[2].ToString());
            //    //System.Diagnostics.Debug.WriteLine(reader[3].ToString());
            //    //System.Diagnostics.Debug.WriteLine(reader[4].ToString());
            //    //System.Diagnostics.Debug.WriteLine(reader[5].ToString());
            //}
            //connection.Close();



        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO testbus(BusName) Values('" + textBox1.Text + "')";
            MySqlCommand commandStuff = conn.CreateCommand();
            MySqlCommand commandStuff2 = new MySqlCommand(sql, conn);
            //commandStuff.CommandText = "INSERT INTO 'testbus'(BusName) Values(?)";
            //commandStuff.Parameters.AddWithValue("BusName", "BUS1");
            //commandStuff.ExecuteNonQuery();
            commandStuff2.ExecuteNonQuery();
        }
    }
}
