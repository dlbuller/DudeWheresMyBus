﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Odbc;
using MySql.Data;
using MySql.Data.MySqlClient;


namespace TestDataBaseConnect
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection conn = null;
        private void connectButton_Click(object sender, EventArgs e)
        {
            string myConnectionString;
            myConnectionString = "Server=bullerman2.crwam3sjtzbj.us-east-2.rds.amazonaws.com;Port=3306;Database=bullerman2;Uid=admin;Pwd=Ollie*651;";
            try
            {
                conn = new MySqlConnection();
                conn.ConnectionString = myConnectionString;
                conn.Open();
                statusTextbox.Text = "Status: Connected";
            }

            catch (MySqlException ex)
            {
                statusTextbox.Text = "Status: Not Connected";
                System.Diagnostics.Debug.WriteLine(ex);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO testbus(BusName) Values('" + textBox1.Text + "')";
            MySqlCommand commandStuff2 = new MySqlCommand(sql, conn);
            commandStuff2.ExecuteNonQuery();
        }
    }
}
